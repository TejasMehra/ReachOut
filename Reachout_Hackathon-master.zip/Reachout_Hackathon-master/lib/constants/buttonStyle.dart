import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:flutter_sizer/flutter_sizer.dart';
//---------------Home Page------------------------------//
const homePageButtonText = TextStyle(
  fontWeight: FontWeight.w400,
  color: Colors.white,
  fontSize: 20.0,
);