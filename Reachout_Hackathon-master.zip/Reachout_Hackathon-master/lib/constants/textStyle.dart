import 'package:flutter/material.dart';

import 'package:google_fonts/google_fonts.dart';

//---------------Home Page------------------------------//
// hello text style
var homePageTextStyle = TextStyle(
  fontWeight: FontWeight.bold,
  color: Colors.black54,
  fontSize: 20.0,
);

// ----------------------------Login Page/Signup Page ----------------